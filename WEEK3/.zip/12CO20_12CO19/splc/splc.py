DNA_CODON_TABLE = {
    'TTT': 'F',     'CTT': 'L',     'ATT': 'I',     'GTT': 'V',
    'TTC': 'F',     'CTC': 'L',     'ATC': 'I',     'GTC': 'V',
    'TTA': 'L',     'CTA': 'L',     'ATA': 'I',     'GTA': 'V',
    'TTG': 'L',     'CTG': 'L',     'ATG': 'M',     'GTG': 'V',
    'TCT': 'S',     'CCT': 'P',     'ACT': 'T',     'GCT': 'A',
    'TCC': 'S',     'CCC': 'P',     'ACC': 'T',     'GCC': 'A',
    'TCA': 'S',     'CCA': 'P',     'ACA': 'T',     'GCA': 'A',
    'TCG': 'S',     'CCG': 'P',     'ACG': 'T',     'GCG': 'A',
    'TAT': 'Y',     'CAT': 'H',     'AAT': 'N',     'GAT': 'D',
    'TAC': 'Y',     'CAC': 'H',     'AAC': 'N',     'GAC': 'D',
    'TAA': '-',     'CAA': 'Q',     'AAA': 'K',     'GAA': 'E',
    'TAG': '-',     'CAG': 'Q',     'AAG': 'K',     'GAG': 'E',
    'TGT': 'C',     'CGT': 'R',     'AGT': 'S',     'GGT': 'G',
    'TGC': 'C',     'CGC': 'R',     'AGC': 'S',     'GGC': 'G',
    'TGA': '-',     'CGA': 'R',     'AGA': 'R',     'GGA': 'G',
    'TGG': 'W',     'CGG': 'R',     'AGG': 'R',     'GGG': 'G'
}


def result(s):
    result = ''

    lines = s
    dna = lines[0]
    introns = lines[1:]

    for intron in introns:
        dna = dna.replace(intron, '')

    for i in range(0, len(dna), 3):
        codon = dna[i:i+3]

        protein = None
        if DNA_CODON_TABLE.has_key(codon):
            protein = DNA_CODON_TABLE[codon]
    
        if protein == '-':
            break

        if protein:
            result += protein

    return ''.join(list(result))


if __name__ == "__main__":

    f = open('rosalind_splc.txt')
    l=f.readlines()
    g=[]
    i=-1;
    for elem in l:
        if elem[0]=='>':
            i+=1
            g.append('')
            continue
        else:
            g[i]+=elem.strip()

    print result(g)

